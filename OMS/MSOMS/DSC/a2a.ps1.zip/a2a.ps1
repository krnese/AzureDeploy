﻿Configuration A2A
{
  
    $A2APackageLocalPath = "C:\A2A\MicrosoftAzureSiteRecoveryUnifiedSetup.exe"
    $A2ASettings = "C:\A2A\a2asettings.ps1"

    Import-DscResource -ModuleName xPSDesiredStateConfiguration

    Node localhost {

        xRemoteFile OMSPackage {
            Uri = "https://aka.ms/unifiedinstaller"
            DestinationPath = $A2APackageLocalPath
        }
        xRemoteFile A2ASettings {
            Uri = "https://raw.githubusercontent.com/krnese/AzureDeploy/master/OMS/MSOMS/DSC/a2asettings.ps1"
            DestinationPath = $A2ASettings
            
        }
    }
}


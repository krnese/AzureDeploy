﻿Configuration OMSServiceMap
{
    $RemoteFile = 'https://aka.ms/dependencyagentwindows'
    $ServiceMapLocalPath = 'C:\ServiceMap\InstallDependencyAgent-Windows.exe'
    $Arguments = $ServiceMapLocalPath + ' /S'

    Import-DscResource -ModuleName xPSDesiredStateConfiguration

    Node localhost {
        Service OMSService
        {
            Name = 'HealthService'
            State = 'Running'
        }
        xRemoteFile ServiceMapPackage {
            Uri = $RemoteFile
            DestinationPath = $ServiceMapLocalPath
        }
        WindowsProcess ServiceMap {
            Ensure = 'Present'
            Path = $ServiceMapLocalPath
            Arguments = $Arguments
            DependsOn = '[xRemoteFile]ServiceMapPackage'
         
        }
        Service ServiceMap {
            Name = 'Microsoft Dependency Agent'
            State = 'Running'
        }
    }
}

OMSServiceMap

Start-DscConfiguration .\omsservicemap -Wait -Force -Verbose
  

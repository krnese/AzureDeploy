﻿Configuration OMSServiceMap
{
    param (
    [Parameter(Mandatory=$true)]
    $OMSWorkspaceId,

    [Parameter(Mandatory=$true)]
    $OMSWorkspaceKey 
    )

    $RemoteFile = 'https://aka.ms/dependencyagentwindows'
    $ServiceMapLocalPath = 'C:\ServiceMap\InstallDependencyAgent-Windows.exe'
    $OMSRemoteFile = 'https://go.microsoft.com/fwlink/?LinkID=517476'
    $OMSLocalPath = 'C:\MMA\MMASetup-AMD64.exe'
    $Arguments = $ServiceMapLocalPath + ' /S'

    Import-DscResource -ModuleName xPSDesiredStateConfiguration

    Node localhost {
        xRemoteFile OMSPackage {
            Uri = $OMSRemoteFile
            DestinationPath = $OMSLocalPath
        }

        WindowsProcess OMS {
            Ensure = "Present"
            Path  = $OMSLocalPath
            Arguments = '/C:"setup.exe /qn ADD_OPINSIGHTS_WORKSPACE=1 OPINSIGHTS_WORKSPACE_ID=' + $OMSWorkspaceId + ' OPINSIGHTS_WORKSPACE_KEY=' + $OMSWorkspaceKey + ' AcceptEndUserLicenseAgreement=1"'
            DependsOn = '[xRemoteFile]OMSPackage'
        }        
        Service OMSService
        {
            Name = 'HealthService'
            State = 'Running'
            DependsOn = '[WindowsProcess]OMS'
        }
        xRemoteFile ServiceMapPackage {
            Uri = $RemoteFile
            DestinationPath = $ServiceMapLocalPath
            DependsOn = '[Service]OMSService'
        }
        WindowsProcess ServiceMap {
            Ensure = 'Present'
            Path = $ServiceMapLocalPath
            Arguments = $Arguments
            DependsOn = '[xRemoteFile]ServiceMapPackage'
         
        }
        Service ServiceMap {
            Name = 'Microsoft Dependency Agent'
            State = 'Running'
            DependsOn = '[WindowsProcess]ServiceMap'
        }
    }
}
configuration ManagedWebApplication 
{
    Node localhost
    {
        WindowsFeature WebServer 
        {
            Name = "Web-Server"
            IncludeAllSubFeature = $true
            Ensure = "Present"
        }
    }
}

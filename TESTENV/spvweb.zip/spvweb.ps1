﻿configuration webtest
{
    node "localhost"
    {
        WindowsFeature web
        {
            Name = "Web-Server"
            Ensure = "Present"
            IncludeAllSubFeature = $true
        }
    }
}
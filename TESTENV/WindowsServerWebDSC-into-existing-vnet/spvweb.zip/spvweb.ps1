﻿configuration webtest
{
    param (
    [Parameter(Mandatory=$true)]
    [string]$servername
    )
    
    node $servername
    {
        WindowsFeature web
        {
            Name = "Web-Server"
            Ensure = "Present"
            IncludeAllSubFeature = $true
        }
    }
}